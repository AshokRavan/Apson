// Function to retrieve notes from local storage
function getNotes() {
    const notes = JSON.parse(localStorage.getItem('notes')) || [];
    return notes;
}

// Function to save notes to local storage
function saveNotes(notes) {
    localStorage.setItem('notes', JSON.stringify(notes));
}

// Function to render notes in the UI
function renderNotes(notes) {
    const notesList = document.getElementById('notesList');
    notesList.innerHTML = '';

    notes.forEach((note, index) => {
        const noteDiv = document.createElement('div');
        noteDiv.classList.add('note');
        noteDiv.innerHTML = `
            <p>${note}</p>
            <button onclick="editNote(${index})">Edit</button>
            <button onclick="deleteNote(${index})">Delete</button>
        `;
        notesList.appendChild(noteDiv);
    });
}

// Function to add a new note
function addNote(noteText) {
    const notes = getNotes();
    notes.push(noteText);
    saveNotes(notes);
    renderNotes(notes);
}

// Function to edit an existing note
function editNote(index) {
    const notes = getNotes();
    const editedNote = prompt('Edit your note:', notes[index]);
    if (editedNote !== null) {
        notes[index] = editedNote;
        saveNotes(notes);
        renderNotes(notes);
    }
}

// Function to delete a note
function deleteNote(index) {
    const notes = getNotes();
    notes.splice(index, 1);
    saveNotes(notes);
    renderNotes(notes);
}

// Event listener for form submission
document.getElementById('noteForm').addEventListener('submit', function(event) {
    event.preventDefault();
    const noteInput = document.getElementById('noteInput');
    const noteText = noteInput.value.trim();
    if (noteText !== '') {
        addNote(noteText);
        noteInput.value = '';
    } else {
        alert('Please enter a note.');
    }
});

// Initial render of notes when the page loads
document.addEventListener('DOMContentLoaded', function() {
    const notes = getNotes();
    renderNotes(notes);
});